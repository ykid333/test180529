package project2;

public interface RacingDevGame {
	//기술자 등록
	public void engineer();
	//드라이버 등록
	public void driver();
	//개발 차 등록
	public void machine();
	//npc 등록
	public void npc();
	
	//경주대회목록 등록
	public void racing();
	
	//게임시작 메소드
	public void fstart();
	public void start();
	
}
