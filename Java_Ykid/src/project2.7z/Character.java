package project2;

public abstract class Character {		//게임에 사용되는 engineer, driver에 대한 부모 클래스
	String name;			//이름
	int sal;				//급여
	int driveskill;			//운전기술
	int mech;				//기술
	int payment;			//계약금
	
}
