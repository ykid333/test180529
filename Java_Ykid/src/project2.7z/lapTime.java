package project2;

public class lapTime { //경주 후 순위를 위한 클래스
	String name;	//선수이름
	int lapTime;	//경기기록
	public lapTime(String name, int lapTime) {
		this.name=name;
		this.lapTime=lapTime;
	}
	
}
